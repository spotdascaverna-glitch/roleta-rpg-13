-- REDE DE SISTEMAS — proteção de mensagens e perfis
-- Faça backup antes de executar no projeto Supabase correto.
-- Este script remove as políticas antigas de system_messages para bloquear acesso anônimo.
-- A confirmação de e-mail é configurada no painel Authentication, não por este SQL.

create table if not exists public.system_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  created_at timestamptz not null default now(),
  constraint system_profiles_username_format check (username ~ '^[A-Za-z0-9_]{3,24}$')
);
create unique index if not exists system_profiles_username_lower_unique
  on public.system_profiles (lower(username));

alter table public.system_messages
  add column if not exists sender_id uuid references auth.users(id) on delete set null;
alter table public.system_messages
  add column if not exists recipient_id uuid references auth.users(id) on delete set null;

create or replace function public.create_system_profile_for_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare chosen_username text;
begin
  chosen_username := new.raw_user_meta_data ->> 'username';
  if chosen_username is null or chosen_username !~ '^[A-Za-z0-9_]{3,24}$' then
    raise exception 'Invalid system username';
  end if;
  insert into public.system_profiles(user_id, username)
  values (new.id, chosen_username);
  return new;
end;
$$;

drop trigger if exists create_system_profile_after_signup on auth.users;
create trigger create_system_profile_after_signup
after insert on auth.users
for each row execute function public.create_system_profile_for_auth_user();

alter table public.system_profiles enable row level security;
alter table public.system_messages enable row level security;

do $$
declare pol record;
begin
  for pol in
    select policyname from pg_policies
    where schemaname = 'public' and tablename = 'system_messages'
  loop
    execute format('drop policy if exists %I on public.system_messages', pol.policyname);
  end loop;
end $$;

drop policy if exists "Authenticated users can view system usernames" on public.system_profiles;
create policy "Authenticated users can view system usernames"
  on public.system_profiles for select to authenticated using (true);

create policy "Authenticated users read public system rooms"
  on public.system_messages for select to authenticated
  using (coalesce(recipient_type, 'room') = 'room');

create policy "Participants read private system messages"
  on public.system_messages for select to authenticated
  using (
    recipient_type = 'private'
    and (sender_id = auth.uid() or recipient_id = auth.uid())
  );

create policy "Authenticated users send own system messages"
  on public.system_messages for insert to authenticated
  with check (
    sender_id = auth.uid()
    and exists (
      select 1 from public.system_profiles p
      where p.user_id = auth.uid() and p.username = sender_name
    )
    and (
      (coalesce(recipient_type, 'room') = 'room' and recipient_id is null)
      or
      (recipient_type = 'private'
       and recipient_id is not null
       and exists (
         select 1 from public.system_profiles target
         where target.user_id = recipient_id and lower(target.username) = lower(private_to)
       ))
    )
    and length(trim(message)) between 1 and 500
  );

revoke all on public.system_profiles from anon, authenticated, public;
revoke all on public.system_messages from anon, authenticated, public;
grant select on public.system_profiles to authenticated;
grant select, insert on public.system_messages to authenticated;

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'system_messages'
  ) then
    alter publication supabase_realtime add table public.system_messages;
  end if;
exception when undefined_object then
  raise notice 'A publicação supabase_realtime não existe; habilite Realtime para system_messages no painel.';
end $$;

-- IMPORTANTE: no painel Supabase, ative a confirmação de e-mail para o provedor Email.
-- Não coloque a chave service_role no HTML; use apenas a chave pública/publishable.
